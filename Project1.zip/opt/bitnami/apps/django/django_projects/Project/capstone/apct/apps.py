from django.apps import AppConfig


class ApctConfig(AppConfig):
    name = 'apct'
